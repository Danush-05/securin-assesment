function transformdata(rawData) {
return rawData?.vulnerabilities?.map(
    item =>  { 
    const v2 = item.cve?.metrics?.cvssMetricV2 ;
    const cvssMetric = v2 ? v2: item.cve?.metrics?.cvssMetricV31;
    const config = item?.cve?.configurations;
    const nodes = config ? config[0]?.nodes : null;
    const cpeMatch = nodes ? nodes[0]?.cpeMatch : null;
    return({
    id: item.cve?.id,
    sourceIdentifier: item.cve?.sourceIdentifier,
    published_date: item.cve?.published,
    last_modified_date: item.cve?.lastModified,
    status: item.cve?.vulnStatus,
    data: {
        description: item.cve?.descriptions[0]?.value,
        CVSS_Metrics: {
            severity: cvssMetric ? cvssMetric[0]?.baseSeverity : null,
            baseScore: cvssMetric ? cvssMetric[0]?.cvssData?.baseScore : null,
            accessVector : cvssMetric ? cvssMetric[0]?.cvssData?.accessVector : null,
            vectorString: cvssMetric ? cvssMetric[0]?.cvssData?.vectorString : null,
            accessComplexity: cvssMetric ? cvssMetric[0]?.cvssData?.accessComplexity : null,
            authentication: cvssMetric ? cvssMetric[0]?.cvssData?.authentication : null,
            confidentialityImpact: cvssMetric ? cvssMetric[0]?.cvssData?.confidentialityImpact : null,
            integrityImpact: cvssMetric ? cvssMetric[0]?.cvssData?.integrityImpact : null,
            availabilityImpact: cvssMetric ? cvssMetric[0]?.cvssData?.availabilityImpact : null,

        },
        scores: {
            exploitabilityScore: cvssMetric ? cvssMetric[0]?.exploitabilityScore : null,
            impactScore: cvssMetric ? cvssMetric[0]?.impactScore : null,
        },
        CPE: cpeMatch ? cpeMatch.map(cpe => ({
            criteria: cpe.criteria,
            match_criteria_id: cpe.matchCriteriaId,
            vulnerable: cpe.vulnerable
        })) : null
        }
    })
}
);
    }

module.exports = transformdata;
