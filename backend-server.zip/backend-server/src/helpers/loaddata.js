require('dotenv').config();
const fetchData = require('./fetchdata');
const transformData = require('./transformdata');
const model = require('../api/models/cve.model');
const {mongoose} = require('mongoose');
const uri = `mongodb+srv://${process.env.MONGO_ID}:${process.env.MONGO_PASS}@securin.8pnseow.mongodb.net/cve?retryWrites=true&w=majority&appName=Securin`
async function loaddata() {
    let page = 0;
    mongoose.connect(uri).then(() => console.log('MongoDB connected')).catch(err => console.log(err));
    let baseUrl = 'https://services.nvd.nist.gov/rest/json/cves/2.0';
    while(page<249088)
    {
        const rawData = await fetchData(baseUrl,page);
        const transformedData = transformData(rawData);
        model.insertMany(transformedData);
        page+=2000;
    }
    console.log('Data loaded');
    mongoose.disconnect();
}

module.exports = loaddata;
