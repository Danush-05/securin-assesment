const axios = require('axios');
const transformdata = require('./transformdata');

async function fetchdata(baseUrl,page) {
try {
    const response = await axios.get(`${baseUrl}?resultsPerPage=2000&startIndex=${page}`);
    console.log(response.data);
    return response.data;
  } catch (error) {
    console.error('Error fetching data:', error);
    return null;
  }
}

module.exports = fetchdata;
