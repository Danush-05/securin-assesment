require("dotenv").config();
const app = require("express")();
app.disable("x-powered-by");
const bodyParser = require("body-parser");
const cors = require("cors");
const morgan = require("morgan");
const PORT = process.env.PORT || 3001;
const loaddata = require("./helpers/loaddata");
const routes = require("./api/routes/routes");
const https = require('https');
const fs = require('fs');
morgan.token("data", (req, res) => {return JSON.stringify(req.body);}); 
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
let corsOptions = {
    origin: "http://localhost:3000",
};

const options = {
key: fs.readFileSync('../backend-server/src/key.pem'),
cert: fs.readFileSync('../backend-server/src/cert.pem'),
minVersion: 'TLSv1.2',
maxVersion: 'TLSv1.3'
};
app.use(cors(corsOptions));

app.use(routes);


async function init() {
	https.createServer(options, app).listen(PORT, () => {
		console.log(`Server is running on port ${PORT}`);
	}
	);
    // loaddata();
}

init();