const model = require('../models/cve.model');
const mongoose = require('mongoose');
const api = mongoose.model('cvedata');
require('dotenv').config();
const uri =`mongodb+srv://${process.env.MONGO_ID}:${process.env.MONGO_PASS}@securin.8pnseow.mongodb.net/cve?retryWrites=true&w=majority&appName=Securin`
const getAllByLimit = async (req, res) => {
    try {
        const connection = await mongoose.connect(uri);
        const page = parseInt(req.query.page);
        const limit = parseInt(req.query.limit);
        const cveDatas = await api.find()
        .sort({ last_modified_date: -1 })
        .skip((page - 1) * limit)
        .limit(limit);
        res.status(200).json(cveDatas);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
}
const getCveDataById = async (req, res) => {
try {
    const connection = await mongoose.connect(uri);
    const cveData = await api.find({ id: req.params.cveId });
    res.status(200).json(cveData);
} catch (error) {
    res.status(500).json({ message: error.message });
}
};
const getCveDataByYear = async (req, res) => {
    try {
        const connection = await mongoose.connect(uri);
        const year  = req.params.year;
        const cveDatas = await api.find({
        published_date: { $regex: new RegExp(year, 'i') }
        });
        const cveids = cveDatas.map((cve) => cve.id);
        res.status(200).json(cveids);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

const getCveDataByScore = async (req, res) => {
    try {
        const connection = await mongoose.connect(uri);
        const cveDatas = await api.find({ "data.CVSS_Metrics.baseScore" : req.params.basescore});
        console.log(cveDatas);
        res.status(200).json(cveDatas);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
const getCveDataByLastModified = async (req, res) => {
    try {
        const connection = await mongoose.connect(uri);
        const days  = req.params.days;
        const dateLimit = new Date();
        dateLimit.setDate(dateLimit.getDate() - days);
        console.log(dateLimit);
        console.log('2019-06-11T20:29:00.263'-dateLimit);
        const cveDatas = await api.find({
        last_modified_date: { $gte: dateLimit }
        });
        res.status(200).json(cveDatas);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};


module.exports = {
    getAllByLimit,
    getCveDataById,
    getCveDataByYear,
    getCveDataByScore,
    getCveDataByLastModified
};
