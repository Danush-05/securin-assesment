const mongoose = require('mongoose');
const cveSchema= new mongoose.Schema({
    id: String,
    index: String,
    sourceIdentifier: String,
    published_date: String,
    last_modified_date: String,
    status: String,
    data: {
    description: String,
    CVSS_Metrics: {
        severity: String,
        baseScore: String,
        accessVector: String,
        vectorString: String,
        accessComplexity:String,
        authentication:String,
        confidentialityImpact:String,
        integrityImpact:String,
        availabilityImpact:String,
        },
    scores: {
        exploitabilityScore: String,
        impactScore: String
    },
    CPE: [{
        criteria: String,
        match_criteria_id: String,
        vulnerable: String
    }]
    }
});

module.exports = mongoose.model('cvedata', cveSchema);
