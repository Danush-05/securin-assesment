const router = require('express').Router();
const cveController = require('../controllers/cve.controller');

router.get('/cves/list', cveController.getAllByLimit);
router.get('/cves/list/:cveId', cveController.getCveDataById);
router.get('/cves/list/year/:year', cveController.getCveDataByYear);
router.get('/cves/list/score/:basescore', cveController.getCveDataByScore);
router.get('/cves/list/lastmodified/:days', cveController.getCveDataByLastModified);


module.exports = router;
