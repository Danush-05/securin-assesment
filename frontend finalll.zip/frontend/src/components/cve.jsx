import { useState,useEffect } from 'react'
import '../styles.css'
import { Footer } from './footer';
import axios from 'axios'
import { useNavigate } from 'react-router-dom';

function Cve() {
    const navigate = useNavigate();


 
  const [size, setSize] = useState(10);
  const [page,setPage]=useState(0)
  const [current,setCurrent]=useState(1)
  const [cvesData,setCvesData]=useState([])
  
  useEffect(()=>{
    const getData=async()=>{
        const data=await axios(`http://localhost:6969/cves/list?page=${page+1}&limit=${size}`) 
        setCvesData(data.data)
      }
    getData()
  },[size,page])

  const handleChange = (event) => {
 
    setSize(event.target.value);
 
  };
  let arr = [];
  for (let i = current; i < current+5; i++) {
    arr.push(i);
  }
  const pages=arr.map((i)=>{
    return (
      <div onClick={()=>{setPage(i-1)}} className={`pages ${(i==page+1)?'active':''}`}>
          {i}
      </div>
    )
  })

  
  const left=()=>{
    setCurrent((prev)=>{
      if(prev!=1)
        return prev-5
      return prev
    })
  }
  const right=()=>{
    setCurrent((prev)=>{
      return prev+5
    })
  }

  const data=[
    {
      id:"1",
      identifier:'1',
      published_date:'1',
      last_modified_date:'1',
      status:'1',
     
    },
    {id:"1",
    identifier:'1',
    published_date:'1',
    last_modified_date:'1',
    status:'1',}
  ]

  const rows=cvesData.map((d)=>{
    return (
      <tr onClick={()=>{navigate(`/cves/${d.id}`)}}>

        <td>{d.id}</td>
        <td>{d.sourceIdentifier}</td>
        <td>{d.published_date}</td>
        <td>{d.last_modified_date}</td>
        <td>{d.status}</td>
      </tr>
  )
  })
  return (
    <div className="body">
   <table className="cves_table" border="1" >
  <tr>
    <th>CVE ID</th>
    <th>IDENTIFIER</th>
    <th>PUBLISHED DATE</th>
    <th>LAST MODIFIED DATE</th>
    <th>STATUS</th>
  </tr>
  {rows}
  </table>
    <Footer page={page} size={size} left={left} right={right} handleChange={handleChange}>{pages}</Footer>
    </div>
  )
}

export default Cve
