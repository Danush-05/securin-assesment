import { useParams } from "react-router-dom"
import {useEffect,useState} from 'react'
import axios from 'axios'
export const CveDetails=()=>{

    const { id } = useParams();
    const [cves,setCves]=useState(null)
    useEffect(()=>{
        const getCvesData=async()=>{
            const data=await axios.get(`http://localhost:6969/cves/list/${id}`)
           setCves(data.data[0].data)
        }
        getCvesData()
    },[])
    console.log(cves)
    const CPE_data=[
        {
            criteria:1,
            match_criteria_id:1,
            vulnerable:1,
        },
        {
            criteria:1,
            match_criteria_id:1,
            vulnerable:1,
        },
        {
            criteria:1,
            match_criteria_id:1,
            vulnerable:1,
        }
    ]
    const CPE=(cves?.CPE ? cves?.CPE.map((item)=>{
        return (<tr>
            <td>{item.criteria}</td>
            <td>{item.match_criteria_id}</td>
            <td>{item.vulnerable}</td>
        </tr>)
    }):"")
    return  (
    <>
        <h1>{id}</h1>
        <h2>Description</h2>
        <p>{cves?.description}</p>
        <h2>CVSS V2 METRICS</h2>
        <div className="score">
            <p><span className="bld">Severity:</span>  {cves?.CVSS_Metrics?.availabilityImpact}</p>
            <p><span className="bld">Score:</span>  <span>  {cves?.CVSS_Metrics?.baseScore}</span></p>
        </div>
        <p><span className="bld">Vector string</span>:  {cves?.CVSS_Metrics?.vectorString}</p>

        <table className="score_table">
            <tr>
                <th>Access Vector</th>
                <th>Access Complexity</th>
                <th>Authentication</th>
                <th>Confidentiality impact</th>
                <th>Integrity impact</th>
                <th>Availabilty impact</th>
            </tr>
            <tr>
                <td>{(cves)?cves?.CVSS_Metrics.accessVector:""}</td>
                <td>{(cves)?cves?.CVSS_Metrics.accessComplexity:""}</td>
                <td>{(cves)?cves?.CVSS_Metrics.authentication:""}</td>
                <td>{(cves)?cves?.CVSS_Metrics.confidentialityImpact:""}</td>
                <td>{(cves)?cves?.CVSS_Metrics.integrityImpact:""}</td>
                <td>{(cves)?cves?.CVSS_Metrics.availabilityImpact:""}</td>
            </tr>
            
        </table>
        <h2>Scores :</h2>
        <p><span className="bld">Exploitability Score:</span> {cves?.scores?.exploitabilityScore}</p>
        <p><span className="bld">Impact Score:</span>  {cves?.scores?.impactScore}</p>
        <h2>CPE</h2>
        <table className="score_table">
            <tr>
                <th>Criteria</th>
                <th>Match Criteria id</th>
                <th>Vulnerable</th>
            </tr>
            {CPE}
        </table>

    </>
    )
}