import '../styles.css'
export const Footer=({page,size,left,right,handleChange,children})=>{
    return(
<div>
    <div className="footer">
        <label>

            <span className="bld">Results per page</span>:

                <select value={size}  onChange={handleChange}>

                <option value={10}>10</option>

                <option value={50}>50</option>

                <option value={100}>100</option>

            </select>
            </label>
            <div className="footer-left">
            <p className="bld">{page*size+1} to {parseInt(page*size)+parseInt(size)} of 249088</p>
            <div className='pagination'>
                <div className='pages' onClick={left}>
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-6 h-6">
                <path stroke-linecap="round" stroke-linejoin="round" d="M15.75 19.5 8.25 12l7.5-7.5" />
                </svg>

                </div>
                {children}
                <div className='pages' onClick={right}>
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-6 h-6">
                <path stroke-linecap="round" stroke-linejoin="round" d="m8.25 4.5 7.5 7.5-7.5 7.5" />
                </svg>

                </div>
            </div>
            </div>



       
    </div>
</div>

    ) 
}