import Cve from './components/cve'
import { CveDetails } from './components/cvedetails'
import './styles.css'

import {Routes,Route} from 'react-router-dom' 
function App() {
  return (
    <Routes>
      {/* <Switch> */}

        <Route path="/cves/list" element={<Cve/>} />
        <Route path="/cves/:id" element={<CveDetails/>} />
      {/* </Switch> */}
    </Routes>
  )
}

export default App
